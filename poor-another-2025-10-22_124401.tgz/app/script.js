let pourCount = 0;
const maxPour = 5;
const hand = document.getElementById("hand");
const glass = document.getElementById("glass");
const liquid = document.getElementById("liquid");
const button = document.getElementById("button");
const poem = document.getElementById("poem");
const body = document.body;

const poems = [
  'You pour yourself a drink. The weather is great. A sip, maybe three - it tastes good.',
  'Another glass. The laughter flows. You feel a warmth in your chest.',
  "You sway as you stand. The hum of the bar fades to walls of a home, trembling like your reaching hand.",
  "A pour without pause, an anger without cause. They must be judging you again; they never understand.",
  "The glass full, the tears spilt, the mirror shattered; a cycle unbroken.",
  "The cycle will remain unbroken. Why did you let it get to this point?"
]

button.addEventListener("click", () => {
  if (pourCount < maxPour) {
    liquid.style.height = `${(pourCount + 1) * 20}%`;

    poem.innerText = poems[pourCount];

    pourCount++;

    if (pourCount === 3) {
      body.classList.remove("bar");
      body.classList.add("home");
    }
    
    setTimeout(() => {
      hand.style.transform = "translateY(50px)";
    }, 1000);

    setTimeout(() => {
      hand.style.transform = "translateY(0)";
      liquid.style.height = "0";
    }, 2000);
  } else {
    button.disabled = true;
    poem.innerText = "The cycle will remain unbroken. Why did you let it get to this point?";
    liquid.style.height = "100%"; 
  }
});
